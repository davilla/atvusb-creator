#!/bin/bash
echo "frontrow" | sudo -S command
sudo shutdown -r now